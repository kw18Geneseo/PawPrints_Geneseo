from django.contrib import admin
from .models import Tag, Petition

admin.site.register(Tag)
admin.site.register(Petition)
