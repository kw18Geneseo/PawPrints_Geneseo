from django.apps import AppConfig


class PetitionsConfig(AppConfig):
    name = 'petitions'
