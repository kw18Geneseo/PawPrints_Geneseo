from django.apps import AppConfig


class SendMailConfig(AppConfig):
    name = 'send_mail'
